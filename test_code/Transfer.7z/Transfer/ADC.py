import time
import Adafruit_ADS1x15
import math
adc = Adafruit_ADS1x15.ADS1115()

GAIN = 1
while True:
    sensorValue = adc.read_adc(0, gain=GAIN)
    #db = (20*math.log(10))*(sensorValue/5);
    print("sensorValue = ")
    print(sensorValue)
    time.sleep(0.5)


        
